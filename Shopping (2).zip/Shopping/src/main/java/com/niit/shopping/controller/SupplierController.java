package com.niit.shopping.controller;


import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shopping.dao.SupplierDAO;
import com.niit.shopping.model.Supplier;




@Controller
public class SupplierController {

	@Autowired
	private SupplierDAO supplierDAO;
	

	@RequestMapping("/addSupplier")
	public ModelAndView addCatey()
	{
		System.out.println("in add view cat");
		List<Supplier> supplierList = supplierDAO.list();
		ModelAndView mv = new ModelAndView("/addSupplier");
		mv.addObject("supplierList", supplierList);
		return mv;
	  	 }
	
	@RequestMapping("/addsSupplier") 
	public ModelAndView addSupplier(@ModelAttribute Supplier supplier) {
		supplierDAO.saveOrUpdate(supplier);
		List<Supplier> supplierList = supplierDAO.list();
		ModelAndView mv = new ModelAndView("/supplierList");
		mv.addObject("supplierList", supplierList);
		return mv;

	 }
	@RequestMapping("updateSupplier") 
	public ModelAndView updateSupplier(@ModelAttribute Supplier supplier) {
		supplierDAO.update(supplier);
		List<Supplier> supplierList = supplierDAO.list();
		ModelAndView mv = new ModelAndView("/supplierList");
		mv.addObject("supplierList", supplierList);
		return mv;

	 }

	
	
	@RequestMapping("supplierlist")
	public ModelAndView addCate()
	{
		System.out.println("in  view cat");
	//	categoryDAO.saveOrUpdate(category);
	  return new ModelAndView("supplierList");
	 }
	
	@RequestMapping(value="deleteSupplier",method = RequestMethod.GET) 
	public ModelAndView deleteSupplier(@RequestParam("delete") String StringId) {
		System.out.println("delete supplier successfully");
		supplierDAO.delete(StringId);
		List<Supplier>supplierList = supplierDAO.list();
		ModelAndView mv = new ModelAndView("/supplierList");
		mv.addObject("supplierList", supplierList);
		return mv;
	 } 

	@RequestMapping("getAllSupplier")
	public ModelAndView getAllSupplier() {

		System.out.println("getAllSupplier");
		
		List<Supplier> supplierList = supplierDAO.list();
		
		ModelAndView mv = new ModelAndView("/ supplierList");
		mv.addObject("supplierList", supplierList);

		return mv;
	}

	@RequestMapping("getAlSupplier")
	public ModelAndView getAlSupplier() {

		System.out.println("getAlSupplier");
		
		List<Supplier> supplierList = supplierDAO.list();
		
	ModelAndView mv = new ModelAndView("/updateSupplier");
	mv.addObject("updateSupplier", supplierList);

		return mv;
	}
	
	

}

