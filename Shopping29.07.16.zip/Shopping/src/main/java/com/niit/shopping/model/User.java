package com.niit.shopping.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {
 
	@Id
	@Column(name = "mail_id")
	private String mail_id;
	private String username;
	private String password;
	private String contactnumber;
	private String birthdate;
	
	public String getMail_id() {
		return mail_id;
	}
	public void setMail_id(String mail_id) {
		this.mail_id = mail_id;
	}
	public String getbirthdate() {
		return birthdate;
	}
	public void setbirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getcontactnumber() {
		return contactnumber;
	}
	public void setcontactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
}
