package h2add;
import java.sql.*;

public class Justfun {
	 public static void main(String[] args) {
	       Connection connection;
	       Statement stmt ;
	       try
	       {
	           Class.forName("org.h2.Driver");
	           connection = DriverManager
	               .getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
	            
	           stmt = connection.createStatement();
	           stmt.execute("INSERT INTO EMPLOYEE (ID,FIRSTNAME,LASTNAME,BIRTHDATE,SALARY)"
	           + "VALUES ('05','ALWIN','RAJ','1993-01-24',20000)");
	       } 
	       catch (Exception e) {
	           e.printStackTrace();
	       }finally {
	           try {
	         
	           } catch (Exception e) {
	               e.printStackTrace();
	           }
	       }
	   }
	}



