package h2add;

import java.sql.*;

public class Add {
	
	public static void main(String[] args) {
	       Connection connection;
	       Statement smt ;
	       try
	       {
	           Class.forName("org.h2.Driver");
	           connection = DriverManager
	               .getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
	            
	           smt = connection.createStatement();
	String sql=("INSERT INTO SHOPPING_CART  (PRODUCT_ID,PRODUCT_NAME,QUANTITY,MERCHANT_NAME,PRICE,STOCK)" 
	           + "VALUES('1006','SKINS','10','KOKKABURRA','10000','2')");
	smt.executeUpdate(sql);
	System.out.println("Inserted records into the table...");
} 
	       catch (Exception e) {
	           e.printStackTrace();
	       }finally {
	           try {
	         
	           } catch (Exception e) {
	               e.printStackTrace();
	           }
	       }
	   }
	}

