package h2add;

import java.sql.*;

public class Delete {
 public static void main(String []args){
	 Connection con;
	 Statement smt;
	 
	 try
     {
         
         con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
          
         smt = con.createStatement();
         
         smt.execute("DELETE FROM EMPLOYEE WHERE ID = 3");
         System.out.println("delete succesfully");
     } 
     catch (Exception e) {
         e.printStackTrace();
     }
     }
  

 }

