package com.niit.shopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shopping.dao.UserDAO;
import com.niit.shopping.model.User;

@Controller
public class UserController {

   @Autowired
	UserDAO userDAO;


	@RequestMapping("/user/isValidUser")
	public ModelAndView showMessage(@RequestParam(value = "username") String username,
			@RequestParam(value = "password") String password) {
		System.out.println("in controller");

		String message;
		ModelAndView mv ;
		
		if (userDAO.isValidUser(username,password)) 
		{
			message = "Successfully Logged in";
			 mv = new ModelAndView("admin");
		} else{
			message="username or password mismatch ";
			mv=new ModelAndView("signin");
		}

		mv.addObject("message", message);
		mv.addObject("username", username);
		return mv;
	}
	@RequestMapping(value = "/user/register")
	public ModelAndView registerUser(@ModelAttribute User user) {
		System.out.println("in reg controller");
		ModelAndView mv = new ModelAndView("/user/register");
		return mv;
	 }
	
	@RequestMapping(value = "/user/signin")
	public ModelAndView signinUser(@ModelAttribute User user) {
		System.out.println("in reg controller");
		ModelAndView mv = new ModelAndView("/user/signin");
		return mv;
	 }

}
