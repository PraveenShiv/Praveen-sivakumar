package com.niit.projectname.DAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.projectname.bean.Category;



@Repository
public class CategoryDAO {
	

 
	public List<Category> getAllCategories() {

		List<Category> list = new ArrayList<Category>();
		Category c1 = new Category();
		c1.setId("CA_Cricket");
		c1.setName("cricket");
		c1.setDescription("This is cricket Category");

		list.add(c1);

		c1 = new Category();
		c1.setId("CAT_EL");
		c1.setName("football");
		c1.setDescription("This is football Category");

		list.add(c1);

		c1 = new Category();
		c1.setId("CAT_HK");
		c1.setName("badminton");
		c1.setDescription("This is Badminton Category");

		list.add(c1);

		return list;

	}
	
	
	public int updateCategories(List<Category>  categoryList)
	{
		
		
		return 1;
	}
	



}




