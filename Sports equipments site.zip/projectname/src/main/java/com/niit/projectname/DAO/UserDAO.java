package com.niit.projectname.DAO;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAO {
	 
 
	
	public String isValidUser(String userName, String password)
	{
		if(userName.equals("pravn")  && password.equals("shiv123")	)
		{
			return "user";
		}
		else if(userName.equals("praveen")  && password.equals("shiv")	)
		{
			return "admin";
		}
		else
		{
			return "none";
		}
	}



}


