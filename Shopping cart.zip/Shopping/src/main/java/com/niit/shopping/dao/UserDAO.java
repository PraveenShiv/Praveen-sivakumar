package com.niit.shopping.dao;


import java.util.List;

import com.niit.shopping.model.User;



public interface UserDAO {


	public List<User> list();

	public User get(String username);

	public void saveOrUpdate(User user);
	
	//public void delete(String id);
	
	public boolean isValidUser(String username, String password);


}